How to run Project
1. Download and Unzip the file on your local system copy carrental .
2. Put carrental folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

Database Configuration

Open phpmyadmin
Create Database carrental
Import database carrental.sql (available SQL File Folder inside zip package)

For User
Open Your browser put inside browser “http://localhost/carrental”
Login Details for user:
Username : test@gmail.com
Password: Test@123

For Admin Panel
Open Your browser put inside browser “http://localhost/carrental/admin”
Login Details for admin :
Username: admin
Password: Test@12345